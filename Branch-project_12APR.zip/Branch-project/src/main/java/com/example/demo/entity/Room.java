package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ROOM")
public class Room {
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE)
	Long roomId;
	String roomType;
	Integer roomOccupancy;
	Integer roomCapacity;
	Integer fee;
	String bookingStatus;
	
	public Room() {}
	public Room(Long roomId, String roomType, Integer roomOccupancy,Integer roomCapacity, Integer fee, String bookingStatus) {
		super();
		this.roomId = roomId;
		this.roomType = roomType;
		this.roomOccupancy = roomOccupancy;
		this.roomCapacity=roomCapacity;
		this.fee = fee;
		this.bookingStatus = bookingStatus;
	}
	public Long getRoomId() {
		return roomId;
	}
	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Integer getRoomOccupancy() {
		return roomOccupancy;
	}
	public void setRoomOccupancy(Integer roomOccupancy) {
		this.roomOccupancy = roomOccupancy;
	}
	
	public Integer getRoomCapacity() {
		return roomCapacity;
	}
	public void setRoomCapacity(Integer roomCapacity) {
		this.roomCapacity = roomCapacity;
	}
	public Integer getFee() {
		return fee;
	}
	public void setFee(Integer fee) {
		this.fee = fee;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	@Override
	public String toString() {
		return "Room [roomId=" + roomId + ", roomType=" + roomType + ", roomOccupancy=" + roomOccupancy
				+ ", roomCapacity=" + roomCapacity + ", fee=" + fee + ", bookingStatus=" + bookingStatus + "]";
	}
	
	

}
