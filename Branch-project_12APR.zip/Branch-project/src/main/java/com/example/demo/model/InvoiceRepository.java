package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Allotment;
import com.example.demo.entity.Invoice;
@Repository
public interface InvoiceRepository extends JpaRepository<Invoice,Long>{
	@Query("select i from Invoice i where i.allotment.allotmentId=:allotmentId")
	Invoice findInvoiceByAllotmentId(@Param("allotmentId") Long allotmentId);

	

}
