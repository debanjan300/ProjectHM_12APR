package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.example.demo.entity.Room;

import com.example.demo.model.RoomRepository;


@Component("rs")
public class RoomService {
	@Autowired
	RoomRepository roomRepository;
	public Room create(Room room) {
		return roomRepository.save(room);
	}
	public List<Room> read() {
		return roomRepository.findAll();
	}
	public Room read(Long roomId)
	{
		return roomRepository.findById(roomId).get();
	}
	
	public Room update(Room room) {
		return roomRepository.save(room);
	}
	public void delete(Long roomId) {
		Room room = roomRepository.findById(roomId).get();
		roomRepository.delete(room);
	}
	public Room updateRoomOccupancy(Room room, String status) {
		//if the occupancy is >1 then  decrease it by 1
		//if occupancy is 1 then make it 0 and also update status to BOOKED
		//else no change
		Integer occupancy = room.getRoomOccupancy();
		if(status=="Approved") {
			
		System.out.println(room);
		System.out.println("Status is Approved"+status);
		if(occupancy>1)
			room.setRoomOccupancy(occupancy-1);
		else if(occupancy==1)
		{
			room.setRoomOccupancy(0);
			room.setBookingStatus("Booked");
		}
		}
		else {
			room.setRoomOccupancy(occupancy+1);
			if(occupancy>0)
				room.setBookingStatus("Available");
		}
	
		return roomRepository.save(room);
	}
//	public Room allotmentReject(Room room)
//	{
//		Integer occupancy=room.getRoomOccupancy();
//		room.setRoomOccupancy(occupancy+1);
//		if(occupancy>0)
//			room.setBookingStatus("Available");
//		return roomRepository.save(room);
//		
//	}
	

}
