package com.example.demo.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Room;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
	@Query("update Room r set r.roomOccupancy=r.roomOccupancy-1 where r.roomId=roomId")
	public int decreaseOccupancy(@Param("roomId") Long roomId);
	@Query("update Room r set r.bookingStatus='Booked' where r.roomOccupancy=0")
	public int booked(@Param("roomOccupancy") Integer roomOccupancy);

}
