package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;
@Repository
public interface UserRepository extends JpaRepository<User, String>{
	@Query("select u from User u where u.userName=:userName and password=:password")
	public User validateLogin(@Param("userName")String userName, @Param("password") String password);
	@Query("select userName from User u")
	public List<String> getAllUserName();
	

}
