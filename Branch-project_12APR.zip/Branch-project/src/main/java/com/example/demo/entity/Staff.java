package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="STAFF")
public class Staff {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long staffId;
    @OneToOne
    private User user;
    private Date dateOfJoining;
    private String designation;
    private Float salary;
    public Staff() {}
	public Staff(Long staffId, User user, Date dateOfJoining, String designation, Float salary) {
		super();
		this.staffId = staffId;
		this.user = user;
		this.dateOfJoining = dateOfJoining;
		this.designation = designation;
		this.salary = salary;
	}
	public Long getStaffId() {
		return staffId;
	}
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Float getSalary() {
		return salary;
	}
	public void setSalary(Float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Staff [staffId=" + staffId + ", user=" + user + ", dateOfJoining=" + dateOfJoining + ", designation="
				+ designation + ", salary=" + salary + "]";
	}
    

}
