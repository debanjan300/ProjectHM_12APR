package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Staff;
import com.example.demo.service.StaffService;

@RequestMapping("/staff")
@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
//@MultipartConfig
public class StaffController {
	@Autowired
    private StaffService staffservice;
    
    @PostMapping("/")
    public Staff addStaff(@RequestBody Staff staff)
    {
        return staffservice.create(staff);
    }
    @GetMapping("/")
    public List<Staff> getAllStaffs()
    {
        List<Staff> staffs=staffservice.read();
        return staffs;
    }
    @GetMapping("/{staffId}")
    public Staff findStaffById(@PathVariable("staffId") Long staffId)
    {
        return staffservice.read(staffId);
    }
    @PutMapping("/")
    public Staff modifyStaff(@RequestBody Staff staff)
    {
        return staffservice.update(staff);
    }
    @DeleteMapping("/{staffId}")
    public void removeStaff(@PathVariable("staffId")Long staffId)
    {
        staffservice.delete(staffId);
    }

}
