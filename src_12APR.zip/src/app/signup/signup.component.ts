import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm:any;
  gotp:any;
  otpError:any;
  selectedFile:any;
  constructor(private fb:FormBuilder, private us:UserService, private router:Router) { 
    this.signupForm=this.fb.group({
      userName:['',[Validators.required,Validators.minLength(6),Validators.maxLength(10)]],
      password:['',[Validators.required,Validators.minLength(8)]],
      cpassword:['',[Validators.required]],
      firstName:['',[Validators.required]],
      lastName:['',[Validators.required]],
      dateOfBirth:['',[Validators.required]],
      address:['',[Validators.required,Validators.minLength(15)]],
      mobile:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
      emailAddress:['duttadebanjan300@gmail.com',[Validators.required,Validators.email]],
      generatedOtp:[''],
      enteredOtp:[''],
      role:['User'],
      status:['SignedUp'],
      photo:['',[Validators.required]]},
      {validators:[this.pwdCheck(),this.mobileCheck(),this.dobCheck(),this.userNameCheck()]
    });
  }
  pwdCheck()
  {
    return (formGroup: FormGroup) =>{
      if (formGroup.controls.cpassword.errors && !formGroup.controls.cpassword.errors.pwdCheck)
        return;
      var status = false;
      var p = formGroup.controls.password.value;
      var cp=formGroup.controls.cpassword.value;
      if(p!=cp)
        status=true;
      //alert(bid.substring(0,1));
      // if (bid.substring(0, 1) != 'B') {
      //   status = true;
      // } else {
      //   var num = bid.substring(1);
      //   if (isNaN(num))
      //     status = true;
      // }
      if (status)
        formGroup.controls.cpassword.setErrors({ 'pwdCheck': true });
      else
        formGroup.controls.cpassword.setErrors(null);
    }
  }

  mobileCheck()
  {
    return (formGroup: FormGroup) =>{
      if (formGroup.controls.mobile.errors && !formGroup.controls.mobile.errors.mobileCheck)
        return;
      var status = false;
      var m = formGroup.controls.mobile.value;
      if(isNaN(m))
        status=true;
      if (status)
        formGroup.controls.mobile.setErrors({ 'mobileCheck': true });
      else
        formGroup.controls.mobile.setErrors(null);
    }
  }
  dobCheck()
  {
    return (formGroup: FormGroup) =>{
      if (formGroup.controls.dateOfBirth.errors && !formGroup.controls.dateOfBirth.errors.dobCheck)
        return;
      var status = false;
      var dt = formGroup.controls.dateOfBirth.value;
      var dob=new Date(dt);
      var todayDate=new Date();
      var ageYear=todayDate.getFullYear() - dob.getFullYear();
       if(ageYear<18)
         status=true;
      if (status)
        formGroup.controls.dateOfBirth.setErrors({ 'dobCheck': true });
      else
        formGroup.controls.dateOfBirth.setErrors(null);
    }
  }
  userNameCheck()
  {
    return (formGroup: FormGroup) =>{
      if (formGroup.controls.userName.errors && !formGroup.controls.userName.errors.userNameCheck)
        return;
      var status = false;
      var userName = formGroup.controls.userName.value;
      // if(isNaN(m))
      //   status=true;
      this.us.getAllUserName().subscribe((data)=>{
       let usernames:String[]=<string[]><any>data;
       for(let a of usernames)
       {
         if(a==userName)
         {
          status=true;
          break;
         }
         else
          continue;  
       }
       if (status)
        formGroup.controls.userName.setErrors({ 'userNameCheck': true });
      else
        formGroup.controls.userName.setErrors(null);
      });
      
    }
  }

  get form()
  {
    return this.signupForm.controls;
  }

  ngOnInit(): void {
  }

  onFileChanged(event:any)
  {
    this.selectedFile=event.target.files[0];
    console.log(JSON.stringify(this.selectedFile));
  }
  addUser()
  {
    var eotp=this.signupForm.controls.enteredOtp.value;
    alert('comparing '+eotp+' with '+this.gotp);
   // alert('adding...');
   if(eotp!=this.gotp)
   {
    this.otpError="Entered otp is invalid!";
     return;
   }
    console.log(this.signupForm.value);
    var formData=new FormData();

    formData.append('userName',this.signupForm.controls.userName.value);
    formData.append('password',this.signupForm.controls.password.value);
    formData.append('firstName',this.signupForm.controls.firstName.value);
    formData.append('lastName',this.signupForm.controls.lastName.value);
    formData.append('dateOfBirth',this.signupForm.controls.dateOfBirth.value);
    formData.append('address',this.signupForm.controls.address.value);
    formData.append('mobile',this.signupForm.controls.mobile.value);
    formData.append('emailAddress',this.signupForm.controls.emailAddress.value);
    formData.append('role',this.signupForm.controls.role.value);
    formData.append('status',this.signupForm.controls.status.value);
    formData.append('photo',this.selectedFile,this.selectedFile.name);
    this.us.addUser(formData).subscribe(data=>{
      console.log(data);
      this.router.navigateByUrl('/(col3:Login)');
    });
  }

  fnGenerateOtp()
  {
    
    var emailAddress=this.signupForm.controls.emailAddress.value;
    console.log(emailAddress);
    this.us.generateOtp(emailAddress).subscribe((data)=>{
     // console.log(data);
      this.gotp=data;      
    });
    // this.signupForm.controls.generatedOtp.value=this.gotp;
  }

}
