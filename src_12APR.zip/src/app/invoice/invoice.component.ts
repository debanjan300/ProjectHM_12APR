import { Component, DoCheck, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
// import * as jsPDF from 'jspdf';
// import * as jsPDF from 'jspdf';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Allotment } from '../allotment';
import { AllotmentService } from '../allotment.service';
import { Invoice } from '../invoice';
import { InvoiceService } from '../invoice.service';
import { Student } from '../student';
import { StudentService } from '../student.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit, DoCheck {
  @ViewChild('content') content: ElementRef | undefined;
  invoices:any;
  role:string="";
  allotments:any;
  studentId:number=0;
  paidAllotmentsByStudent:any="";
  unpaidAllotmentsByStudent:any="";
  tableData:string[][]=[['1','2','3']];
  header=[['Invoice ID', 'Invoice Date', 'Allotment ID','First Name','Last Name','Paid fee']];
  
  loggedRole:string|null="";
  constructor(private is:InvoiceService, private router:Router, private as:AllotmentService, private ss:StudentService) { }
  ngDoCheck(): void {
    var strRole= localStorage.getItem("loggedRole");
   if(strRole!=null)
    this.role=strRole;
    else
      this.role="";
  }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    this.loggedRole=localStorage.getItem("loggedRole");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{ 
    this.getAllInvoices();
    this.getPaidAllotmentByStudentId();
    this.getUnPaidAllotmentByStudentId();
      
    }
  }
  fnPayment(a:Allotment)
  {
    alert("Your payment is done. Download your invoice");
    //Long invoiceId, Allotment allotment, Date invoiceDate
    var invoice:Invoice=new Invoice();
    invoice.invoiceDate=new Date();
    invoice.allotment=a;
    this.is.addInvoice(invoice).subscribe((data)=>{
      console.log("fnPayment says:"+data);
      this.getPaidAllotmentByStudentId();
    this.getUnPaidAllotmentByStudentId();
    });
  }
  fnDownloadInvoice(allotmentId)
  {
    var invoice:Invoice=new Invoice();
    this.is.findInvoiceByAllotmentId(allotmentId).subscribe((dt)=>{
      invoice=<Invoice><any>dt;
      console.log("fnDownloadInvoice says:"+JSON.stringify(invoice));
      // this.tableData.push([]);
      this.tableData[0].pop();
      this.tableData[0].pop();
      this.tableData[0].pop();
      
     this.tableData[0].push(invoice.invoiceId+"");
     var idate=JSON.stringify(invoice.invoiceDate);
     var idate2=idate.substring(1,11);
     this.tableData[0].push(idate2);
     this.tableData[0].push(invoice.allotment.allotmentId+"");
     this.tableData[0].push(invoice.allotment.student.user.firstName);
     this.tableData[0].push(invoice.allotment.student.user.lastName);
     this.tableData[0].push(invoice.allotment.room.fee+"");
     console.log(this.tableData);

     let doc= new jsPDF();
     doc.text('INVOICE', 90, 8);
     
    doc.setFontSize(12);
    doc.setTextColor(99);
    (doc as any).autoTable({
     head: this.header,
    body: this.tableData,
    theme: 'grid',
    // didDrawCell: data => {
    //     console.log(data.column.index)
    // }
    })
    doc.text('Keep a hard copy of this.', 11,50)

     doc.output('dataurlnewwindow');
   // doc.save('invoice.pdf');
    

    });
    //alert("Your invoice is downloading!!");
    // let doc=new jsPDF();
    // let doc= new jsPDF();
       //doc.text('Hello Invoice!',11,8);
    // doc.setFontSize(12);
    // doc.setTextColor(99);

    // (doc as any).autoTable({
    //   body: this.paidAllotmentsByStudent,
    //   theme: 'plain',
    //   didDrawnCell: data => {
    //     console.log(data.column.index);
    //   }
    // })

    // let specialElementHandlers={
    //   '#editor': function(element, renderer){
    //     return true;
    //   }
    // };

    // let content=this.content?.nativeElement;

    // doc.fromHTML(content.innerHTML,15,15, {
    //   'width': 190,
    //   'elementHandlers': specialElementHandlers,
    // });
    // doc.output('dataurlnewwindow');
    // doc.save('invoice.pdf');
  }

  getAllInvoices() {
    this.is.getAllInvoices().subscribe((data) => {
      console.log(data);
      this.invoices = data;
    });
  }
  getAllAllotments() {
    this.as.getAllAllotment().subscribe((data) => {
      console.log(data);
      this.allotments = data;
    });
  }
  getPaidAllotmentByStudentId()
  {
    var student: Student = new Student();
    // var allotment:Allotment=new Allotment();
    var userName: string | any = localStorage.getItem('loggedUserName');
   this.ss.findStudentByUserName(userName).subscribe((data)=>{
     student= <any>data;
    this.studentId=student.studentId;
    this.as.findPaidAllotmentsByStudentId(this.studentId).subscribe((data1)=>{
      this.paidAllotmentsByStudent=<any>data1;
     // this.getAllAllotments();
    });
   });
  }
  getUnPaidAllotmentByStudentId()
  {
    var student: Student = new Student();
    // var allotment:Allotment=new Allotment();
    var userName: string | any = localStorage.getItem('loggedUserName');
   this.ss.findStudentByUserName(userName).subscribe((data)=>{
     student= <any>data;
    this.studentId=student.studentId;
    this.as.findUnPaidAllotmentsByStudentId(this.studentId).subscribe((data1)=>{
      this.unpaidAllotmentsByStudent=<any>data1;
     // this.getAllAllotments();
    });
   });
  }


}

